import fs from 'fs';
import path from 'path';

export default function handler(req, res) {
  const query = (req.query.q || "").toLowerCase();

  const filePath = path.join(process.cwd(), 'data', 'scanned_urls_202511182216.csv');
  const raw = fs.readFileSync(filePath, 'utf8');

  const lines = raw.split('\n').filter(Boolean);

  let results = [];

  for (const line of lines) {
    // Separación por TAB o por COMA (acepta ambos)
    const parts = line.includes('\t') ? line.split('\t') : line.split(',');

    if (parts.length < 3) continue;

    const [id, url, title] = parts.map(x => x.trim());

    // Buscar coincidencias por texto
    if (title.toLowerCase().includes(query)) {
      results.push({
        id,
        url,
        title,
        similarity: 1, // si solo buscas coincidencia exacta
        bits: "N/A"
      });
    }
  }

  res.status(200).json({ results });
}
