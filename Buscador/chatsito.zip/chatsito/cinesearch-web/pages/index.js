import { useState } from 'react';

export default function Home() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setSearched(true);
    setResults([]);

    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
      const data = await res.json();
      setResults(data.results || []);
    } catch (error) {
      console.error("Error buscando:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="main-container">

      {/* Título */}
      <h1 className="app-title">CineSearch <span style={{ color: "#2563eb" }}>LSH</span></h1>
      <p className="app-subtitle">
        Motor de búsqueda semántica potenciado por MinHash y LSH Forest.
      </p>

      {/* Barra de búsqueda */}
      <form className="search-box" onSubmit={handleSearch}>
        <input
          type="text"
          placeholder="Buscar una película..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />

        <button type="submit" className="search-btn" disabled={loading}>
          {loading ? "..." : "Buscar"}
        </button>
      </form>

      {/* Estado de carga */}
      {loading && (
        <div className="no-results">
          <p>Buscando similitudes...</p>
        </div>
      )}

      {/* Sin resultados */}
      {!loading && searched && results.length === 0 && (
        <div className="no-results">
          <p>No encontramos resultados para "{query}".</p>
          <p style={{ fontSize: "0.9rem", marginTop: "4px" }}>
            Prueba con otras palabras clave.
          </p>
        </div>
      )}

      {/* Resultados */}
      <div>
        {results.map((movie) => (
          <div key={movie.id} className="result-card">
            <h2 className="result-title">
              <a href={movie.url} target="_blank" rel="noopener noreferrer">
                {movie.title}
              </a>
              <span className="similarity-badge">
                {(movie.similarity * 100).toFixed(1)}%
              </span>
            </h2>

            <p className="result-desc">
              {movie.description || "Sin descripción disponible."}
            </p>

            <div 
              style={{
                marginTop: "10px",
                fontSize: "0.75rem",
                color: "#6b7280",
                background: "#f9fafb",
                padding: "6px 10px",
                borderRadius: "8px",
                fontFamily: "monospace"
              }}
            >
              <strong>COMPRIMIDO:</strong> {movie.bits}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
